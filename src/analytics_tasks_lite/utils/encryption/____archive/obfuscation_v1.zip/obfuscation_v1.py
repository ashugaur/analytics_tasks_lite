# %% Obfuscation

import os
import re
import base64
import tempfile

def convert_html_to_offline(
    input_html,
    output_html,
    js_libraries=None,
    verify=True,
    add_browser_check=True,
):


    if not os.path.exists(input_html):
        raise FileNotFoundError(f"Input HTML file not found at: {input_html}")

    # Normalize js_libraries to dict format
    js_lib_map = {}

    if js_libraries is None:
        raise ValueError("js_libraries parameter is required")
    elif isinstance(js_libraries, str):
        # Single file - assume it's ECharts
        js_lib_map["echarts"] = js_libraries
    elif isinstance(js_libraries, list):
        # List of files - try to auto-detect library type
        for lib_path in js_libraries:
            lib_name = os.path.basename(lib_path).lower()
            if "echarts" in lib_name:
                js_lib_map["echarts"] = lib_path
            elif "d3-sankey" in lib_name or "d3.sankey" in lib_name:
                js_lib_map["d3-sankey"] = lib_path
            elif "d3" in lib_name and "sankey" not in lib_name:
                js_lib_map["d3"] = lib_path
            else:
                # Generic name based on filename
                key = lib_name.replace(".min.js", "").replace(".js", "")
                js_lib_map[key] = lib_path
    elif isinstance(js_libraries, dict):
        js_lib_map = js_libraries
    else:
        raise ValueError("js_libraries must be str, list, or dict")

    # Verify library files exist
    for lib_name, lib_path in js_lib_map.items():
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"{lib_name} JS file not found at: {lib_path}")

    # Read the input HTML
    with open(input_html, "r", encoding="utf-8") as f:
        html_content = f.read()


    # Define CDN patterns for different libraries
    cdn_patterns = {
        "echarts": [
            r'<script[^>]*\s+src\s*=\s*"https://assets\.pyecharts\.org/[^"]*echarts[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdn\.jsdelivr\.net/[^"]*echarts[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdnjs\.cloudflare\.com/[^"]*echarts[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://fastly\.jsdelivr\.net/[^"]*echarts[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://unpkg\.com/[^"]*echarts[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https?://[^"]*echarts[^"]*\.js"[^>]*></script>',
        ],
        "d3": [
            r'<script[^>]*\s+src\s*=\s*"https://d3js\.org/d3[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdn\.jsdelivr\.net/[^"]*\bd3[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdnjs\.cloudflare\.com/[^"]*\bd3[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://unpkg\.com/d3@[^"]*\.js"[^>]*></script>',
        ],
        "d3-sankey": [
            r'<script[^>]*\s+src\s*=\s*"https://unpkg\.com/d3-sankey@[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdn\.jsdelivr\.net/[^"]*d3-sankey[^"]*\.js"[^>]*></script>',
            r'<script[^>]*\s+src\s*=\s*"https://cdnjs\.cloudflare\.com/[^"]*d3-sankey[^"]*\.js"[^>]*></script>',
        ],
    }

    # Replace each library's CDN references
    replaced_count = 0

    for lib_name, lib_path in js_lib_map.items():
        # Read the library content
        with open(lib_path, "r", encoding="utf-8") as f:
            lib_content = f.read()

        embedded_script = f'<script type="text/javascript">\n/* Embedded {lib_name.upper()} Library */\n{lib_content}\n</script>'

        # Get patterns for this library
        patterns = cdn_patterns.get(lib_name, [])

        # Try each pattern
        replaced = False
        for pattern in patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                start, end = match.span()
                html_content = (
                    html_content[:start] + embedded_script + html_content[end:]
                )
                replaced = True
                replaced_count += 1
                print(f"✓ Replaced {lib_name} CDN link: {match.group()[:80]}...")
                break

        if not replaced:
            print(f"⚠️  Warning: No {lib_name} CDN link found to replace")

    if replaced_count == 0:
        print("⚠️  Warning: No CDN links were replaced.")
        # Show what script tags we DID find
        script_tags = re.findall(r'<script[^>]*\s+src\s*=\s*"([^"]+)"[^>]*>', html_content, re.IGNORECASE)
        if script_tags:
            print(" Found these script sources:")
            for tag in script_tags:
                print(f"   - {tag}")
    else:
        print(f"\n✅ Successfully replaced {replaced_count} CDN link(s)")

    # Add browser verification if requested
    if add_browser_check:
        verification_script = """
<script type="text/javascript">
// Offline Verification Check
(function() {
    'use strict';
    window.addEventListener('load', function() {
        console.log('%c==============================', 'color: #4CAF50;');
        console.log('%c🔍 OFFLINE MODE VERIFICATION CHECK', 'color: #4CAF50; font-size: 16px; font-weight: bold;');
        console.log('%c==============================', 'color: #4CAF50;');

        var issues = [];
        var warnings = [];
        var info = [];

        // Check 1: Verify libraries are loaded
        var libraries = {
            'ECharts': typeof echarts !== 'undefined',
            'D3': typeof d3 !== 'undefined'
        };

        for (var lib in libraries) {
            if (libraries[lib]) {
                console.log('%c✅ ' + lib + ' library is loaded', 'color: #4CAF50;');
                if (lib === 'ECharts' && typeof echarts !== 'undefined') {
                    info.push('ECharts version: ' + (echarts.version || 'unknown'));
                }
                if (lib === 'D3' && typeof d3 !== 'undefined') {
                    info.push('D3 version: ' + (d3.version || 'unknown'));
                }
            }
        }

        // Check 2: Scan for external script sources
        var scripts = document.querySelectorAll('script[src]');
        var externalScripts = [];
        scripts.forEach(function(script) {
            var src = script.getAttribute('src');
            if (src && (src.startsWith('http://') || src.startsWith('https://'))) {
                externalScripts.push(src);
            }
        });

        if (externalScripts.length > 0) {
            console.warn('%c⚠️  Found ' + externalScripts.length + ' external script(s):', 'color: #ff9800; font-weight: bold;');
            externalScripts.forEach(function(src) {
                console.warn('%c   - ' + src, 'color: #ff9800;');
                warnings.push('External script: ' + src);
            });
        } else {
            console.log('%c✅ No external scripts detected', 'color: #4CAF50;');
        }

        // Check 3: Scan for external stylesheets
        var links = document.querySelectorAll('link[rel="stylesheet"][href]');
        var externalCSS = [];
        links.forEach(function(link) {
            var href = link.getAttribute('href');
            if (href && (href.startsWith('http://') || href.startsWith('https://')))
            {
                externalCSS.push(href);
            }
        });

        if (externalCSS.length > 0) {
            console.warn('%c⚠️  Found ' + externalCSS.length + ' external stylesheet(s)', 'color: #ff9800;');
            warnings.push(externalCSS.length + ' external stylesheets');
        } else {
            console.log('%c✅ No external stylesheets detected', 'color: #4CAF50;');
        }

        // Check 4: Scan for external images
        var images = document.querySelectorAll('img[src]');
        var externalImages = [];
        images.forEach(function(img) {
            var src = img.getAttribute('src');
            if (src && (src.startsWith('http://') || src.startsWith('https://'))) {
                externalImages.push(src);
            }
        });

        if (externalImages.length > 0) {
            console.warn('%c⚠️  Found ' + externalImages.length + ' external image(s)', 'color: #ff9800;');
            warnings.push(externalImages.length + ' external images');
        } else {
            console.log('%c✅ No external images detected', 'color: #4CAF50;');
        }

        // Final summary
        console.log('%c==============================', 'color: #4CAF50; font-weight: bold;');

        if (issues.length === 0 && warnings.length === 0) {
            console.log('%c🎉 SUCCESS: This page is completely OFFLINE!', 'color: #4CAF50; font-size: 14px; font-weight: bold; background: #e8f5e9; padding: 5px;');
        } else if (issues.length > 0) {
            console.error('%c❌  FAILED: Critical issues found (' + issues.length + ')', 'color: #f44336; font-size: 14px; font-weight: bold;');
        } else if (warnings.length > 0) {
            console.warn('%c⚠️  PARTIAL: Warnings found (' + warnings.length + ')', 'color: #ff9800; font-size: 14px; font-weight: bold;');
        }

        // Additional info
        if (info.length > 0) {
            console.log('%cℹ️  Additional Info:', 'color: #2196F3; font-weight: bold;');
            info.forEach(function(i) {
                console.log('%c - ' + i, 'color: #2196F3;');
            });
        }

        console.log('%c==============================', 'color: #4CAF50;');

        window.offlineVerification = {
            isOffline: issues.length === 0 && warnings.length === 0,
            issues: issues,
            warnings: warnings,
            info: info
        };

        console.log('%cℹ️  Access detailed results: window.offlineVerification', 'color: #2196F3;');
    });
})();
</script>
"""
        body_close = html_content.rfind("</body>")
        if body_close != -1:
            html_content = (
                html_content[:body_close]
                + verification_script
                + html_content[body_close:]
            )
        else:
            html_content += verification_script

    with open(output_html, "w", encoding="utf-8") as f:
        f.write(html_content)
    if verify:
        external_refs = re.findall(
            r'(?:src|href)\s*=\s*"(https?://[^"]+)"', html_content
        )
        if external_refs:
            print(
                f"\n⚠️  Warning: HTML still contains {len(external_refs)} external references(s):"
            )
            for ref in external_refs[:5]:
                print(f"  - {ref}")
            if len(external_refs) > 5:
                print(f"   ... and {len(external_refs) - 5} more")
        else:
            print("\n✅ Fully offline HTML saved")

    original_size = os.path.getsize(input_html)
    output_size = os.path.getsize(output_html)
    print(f"📊 File size: {original_size / 1024:.1f} KB → {output_size / 1024:.1f} KB")


def obfuscate_html(
    input_file,
    output_file,
    add_warning=True,
    company_name="Company Inc.",
    preserve_unicode=True,
):
    """
    Obfuscate HTML file with Unicode character preservation """
    with open(input_file, "r", encoding="utf-8") as f:
        html_content = f.read()

    encoded_content = base64.b64encode(html_content.encode("utf-8")).decode("utf-8")
    encoding_note = "Base64 (UTF-8 preserved)" if preserve_unicode else "Base64"

    warning_banner = ""
    if add_warning:
        warning_banner = f"""
    <div id="warning-banner" style="
        background: linear-gradient(135deg, #8856a7 0%, #c23899 100%); # Blue
        color: white;
        padding: 5px 10px;
        text-align: center;
        font-family: Arial, sans-serif;
        font-size: 10px;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 99999;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    ">
        <strong>⚠️  {company_name.upper()} INTERNAL USE ONLY</strong> |
        Unauthorized distribution or extraction of data is prohibited
    </div>
    <div style="height: 35px;"></div>
"""

    obfuscated_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
</head>
<body>
    <script>
        // Obfuscated content loader
        // Encoding: {encoding_note}
        (function() {{
            'use strict';

            var encodedContent = "{encoded_content}";

            try {{
                var decodedContent = atob(encodedContent);
                var bytes = new Uint8Array(decodedContent.length);
                for (var i = 0; i < decodedContent.length; i++) {{
                    bytes[i] = decodedContent.charCodeAt(i);
                }}
                var decoder = new TextDecoder('utf-8');
                var utf8Content = decoder.decode(bytes);

                document.open();
                document.write(utf8Content);
                document.close();

                setTimeout(function() {{
                    var banner = `{warning_banner}`;
                    if (banner && document.body) {{
                        document.body.insertAdjacentHTML('afterbegin', banner);
                    }}
                }}, 50);

            }} catch(e) {{
                document.body.innerHTML = '<div style="padding:20px;color:red;">Error loading content. Please contact support.</div>';
                console.error('Decoding error:', e);
            }}

            if (typeof console !== 'undefined') {{
                console.log('%c⚠️  STOP!', 'color: red; font-size: 40px; font-weight: bold;');
                console.log('%c{company_name} internal report.', 'font-size: 16px;');
                console.log('%cUnauthorized access or data extraction may violate company policy.', 'font-size: 14px;');
            }}
        }})();
    </script>
</body>
</html>'''

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(obfuscated_html)

    original_size = os.path.getsize(input_file)
    obfuscated_size = os.path.getsize(output_file)

    print("✅ Obfuscation complete!")
    print(f"   Input:  {os.path.basename(input_file)}")
    print(f"   Output: {os.path.basename(output_file)}")
    print(f"   Size:   {original_size:,} bytes → {obfuscated_size:,} bytes")
    if preserve_unicode:
        print(" ✓ Unicode characters preserved (⭐🎉💩💢🔅💥 etc.)")


def create_protected_offline_html(
    input_html,
    output_html,
    js_libraries, # Now accepts str, list, or dict
    company_name="Company Inc.",
    preserve_unicode=True,
    add_warning=True,
    verify_offline=True,):

    print("=" * 70)
    print("STEP 1: Converting to OFFLINE mode...")
    print("=" * 70)

    temp_offline = tempfile.mktemp(suffix="__offline.html")

    try:
        convert_html_to_offline(
            input_html,
            temp_offline,
            js_libraries=js_libraries,
            verify=True,
            add_browser_check=True,)

        if verify_offline:
            with open(temp_offline, "r", encoding="utf-8") as f:
                content = f.read()

            external_refs = re.findall(r'(?:src|href)\s*=\s*"(https?://[^"]+)"', content)

            if external_refs:
                print("\n❌  ERROR: File is NOT fully offline!")
                print("   Found external references.")
                for ref in external_refs[:10]:
                    print(f"   - {ref}")
                print("\n⚠️  Cannot obfuscate a file with external dependencies.")

                os.unlink(temp_offline)
                return False
            else:
                print("\n✅ Verification passed: File is fully offline")

        print("\n" + "=" * 70)
        print("STEP 2: Applying OBFUSCATION (with Unicode preservation)...")
        print("=" * 70)

        obfuscate_html(
            temp_offline,
            output_html,
            add_warning=add_warning,
            company_name=company_name,
            preserve_unicode=preserve_unicode,
        )

        os.unlink(temp_offline)
        print("\n" + "=" * 70)
        print("✅ COMPLETE! File is now offline and obfuscated.")
        print("=" * 70)
        print(f" Output: {output_html}")
        print("\n💡  Test by opening in browser and checking console (F12)")

        return True

    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback

        traceback.print_exc()
        if os.path.exists(temp_offline):
            os.unlink(temp_offline)
        return False

if __name__ == "__main__":
    success = create_protected_offline_html(
    input_html=r"C:\my_disk\____tmp\test_stress.html",
    output_html=r"C:\my_disk\____tmp\test_stress_protected.html",
    js_libraries=[r"C:\my_disk\projects\visual_library\____settings\js\echarts.min.js",
                  r"C:\my_disk\projects\visual_library\____settings\js\d3-sankey.min.js",
                  r"C:\my_disk\projects\visual_library\____settings\js\d3.v7.min.js"],
    company_name="Company Inc.",
    preserve_unicode=True,
    add_warning=True,
    verify_offline=True,
    )

